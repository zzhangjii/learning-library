#!/bin/bash

/home/opc/instantclient_12_2/sqlplus admin/Alpha2018___@orcl_high << EOF

create user $JS_USR identified by Alpha2018___;

grant oml_developer to $JS_USR;

begin
--
dbms_scheduler.create_job( 
job_name => 'drop_user',
job_type => 'PLSQL_BLOCK',
job_action => 'begin execute immediate ''drop user $JS_USR cascade''; end;',
start_date => sysdate+(1/24/2),
enabled => true);
end;
/ 

EOF

