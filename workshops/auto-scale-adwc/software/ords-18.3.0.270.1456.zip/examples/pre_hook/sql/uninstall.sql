drop user pre_hook_defns cascade;
drop user pre_hook_tests cascade;

quit
