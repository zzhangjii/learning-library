set define '^' verify off
prompt ...wwv_flows_version
create or replace function wwv_flows_version wrapped 
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
84 aa
JkfJOTB5EPAvF6qb8Y9O1hvwfYwwg8eZgcfLCNL+XhaWlm2u2fqWlkqWDGLF/0dyXufAsr2y
m17nx3TAM7h0ZQm4dItmpm5xVQBzU46ppuV4enpWGdfGJHoZf91ecq0ihT3GPX+0KhmVf9sq
IlcUhezZPXKV7PumfvMcwQ==

/
