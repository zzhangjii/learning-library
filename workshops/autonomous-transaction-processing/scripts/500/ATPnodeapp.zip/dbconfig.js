module.exports= {
    dbuser: 'admin',
    dbpassword: 'WElcome_123#',
    connectString: 'ATPTEJUS_high'
    }