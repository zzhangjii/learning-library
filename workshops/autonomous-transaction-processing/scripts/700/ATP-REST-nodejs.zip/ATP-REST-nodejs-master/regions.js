/*
    Version 1.1

   Oracle Cloud Infrastructure Regions
   Author: kris.bhanushali@oracle.com
*/


var coreServicesPhoenixRegion = "iaas.us-phoenix-1.oraclecloud.com";
var coreServicesAshburnRegion = "iaas.us-ashburn-1.oraclecloud.com";
var coreServicesFrankfurtRegion = "iaas.eu-frankfurt-1.oraclecloud.com";
var coreServicesLondonRegion = "iaas.uk-london-1.oraclecloud.com";

var dbPhoenixRegion = "database.us-phoenix-1.oraclecloud.com";
var dbAshburnRegion = "database.us-ashburn-1.oraclecloud.com";
var dbFrankfurtRegion = "database.eu-frankfurt-1.oraclecloud.com";
var dbLondonRegion = "database.uk-london-1.oraclecloud.com";

var iamPhoenixRegion = "identity.us-phoenix-1.oraclecloud.com";
var iamAshburnRegion = "identity.us-ashburn-1.oraclecloud.com";
var iamFrankfurtRegion = "identity.eu-frankfurt-1.oraclecloud.com";
var iamLondonRegion = "identity.uk-london-1.oraclecloud.com";

var objectStorePhoenixRegion ="objectstorage.us-phoenix-1.oraclecloud.com";
var objectStoreAshburnRegion ="objectstorage.us-ashburn-1.oraclecloud.com";
var objectStoreFrankfurtRegion ="objectstorage.eu-frankfurt-1.oraclecloud.com";
var objectStoreLondonRegion = "objectstorage.uk-london-1.oraclecloud.com";

var dnsPhoenixRegion = "dns.us-phoenix-1.oraclecloud.com";
var dnsAshburnRegion = "dns.us-ashburn-1.oraclecloud.com";
var dnsFrankfurtRegion ="dns.eu-frankfurt-1.oraclecloud.com";
var dnsLondonRegion = "dns.uk-london-1.oraclecloud.com";

var containerEnginePhoenixRegion ="containerengine.us-phoenix-1.oraclecloud.com";
var containerEngineAshburnRegion ="containerengine.us-ashburn-1.oraclecloud.com";
var containerEngineFrankfurtRegion ="containerengine.eu-frankfurt-1.oraclecloud.com";
var containerEngineLondonRegion = "containerengine.uk-london-1.oraclecloud.com";

var auditPhoenixRegion ="audit.us-phoenix-1.oraclecloud.com";
var auditAshburnRegion ="audit.us-ashburn-1.oraclecloud.com";
var auditFrankfurtRegion ="audit.eu-frankfurt-1.oraclecloud.com";
var auditLondonRegion = "audit.uk-london-1.oraclecloud.com";

var loadBalancerPhoenixRegion ="iaas.us-phoenix-1.oraclecloud.com";
var loadBalancerAshburnRegion ="iaas.us-ashburn-1.oraclecloud.com";
var loadBalancerFrankfurtRegion ="iaas.eu-frankfurt-1.oraclecloud.com";
var loadBalancerLondonRegion = "iaas.uk-london-1.oraclecloud.com";

module.exports = {
coreServicesPhoenixRegion: coreServicesPhoenixRegion,
coreServicesAshburnRegion: coreServicesAshburnRegion,
coreServicesFrankfurtRegion: coreServicesFrankfurtRegion,
coreServicesLondonRegion: coreServicesLondonRegion,
dbPhoenixRegion:dbPhoenixRegion,
dbAshburnRegion:dbAshburnRegion,
dbFrankfurtRegion:dbFrankfurtRegion,
dbLondonRegion:dbAshburnRegion,
iamPhoenixRegion:iamPhoenixRegion,
iamAshburnRegion:iamAshburnRegion,
iamFrankfurtRegion:iamFrankfurtRegion,
iamLondonRegion:iamLondonRegion,
objectStorePhoenixRegion:objectStorePhoenixRegion,
objectStoreAshburnRegion:objectStoreAshburnRegion,
objectStoreFrankfurtRegion:objectStoreFrankfurtRegion,
objectStoreLondonRegion:objectStoreLondonRegion,
dnsPhoenixRegion:dnsPhoenixRegion,
dnsAshburnRegion:dnsAshburnRegion,
dnsFrankfurtRegion:dnsFrankfurtRegion,
dnsLondonRegion:dnsLondonRegion,
containerEnginePhoenixRegion:containerEnginePhoenixRegion,
containerEngineAshburnRegion:containerEngineAshburnRegion,
containerEngineFrankfurtRegion:containerEngineFrankfurtRegion,
containerEngineLondonRegion:containerEngineLondonRegion,
auditPhoenixRegion:auditPhoenixRegion,
auditAshburnRegion:auditAshburnRegion,
auditFrankfurtRegion:auditFrankfurtRegion,
auditLondonRegion:auditLondonRegion,
loadBalancerPhoenixRegion:loadBalancerPhoenixRegion,
loadBalancerAshburnRegion:loadBalancerAshburnRegion,
loadBalancerFrankfurtRegion:loadBalancerFrankfurtRegion,
loadBalancerLondonRegion:loadBalancerLondonRegion

};


