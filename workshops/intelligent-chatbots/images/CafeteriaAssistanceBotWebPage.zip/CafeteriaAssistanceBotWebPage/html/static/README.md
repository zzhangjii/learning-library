# static

Files and directories that you put in `static` will be copied to the
`dist/static` directory during the build step. Use it to provide
arbitrary static assets that can be referenced by path in your
application.
