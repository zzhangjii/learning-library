var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var path = require('path');
var https = require("https");
var request = require('request');

app.use(bodyParser.urlencoded({ extended: true })); 
app.use(express.static(path.join(__dirname, 'html')));

app.get('/',function(req,res){	
	res.sendFile(__dirname + "html/index.html");
});

var port = process.env.PORT || 8080;
app.listen(port, function(){
	console.log('listening on' + port )
});
