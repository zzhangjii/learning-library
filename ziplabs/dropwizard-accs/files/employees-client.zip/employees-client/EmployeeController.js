var app = angular.module('demo', [])
.directive('file', function () {
    return {
        scope: {
            file: '='
        },
		require:'ngModel',
        link: function (scope, el, attrs, ngModel) {
            el.bind('change', function (event) {
                var file = event.target.files[0];
                scope.file = file ? file : undefined;
				console.log(file);
               
				scope.$apply(function(){
				  ngModel.$setViewValue(el.val());
				  ngModel.$render();
				});
				
			});
			//el.val(null):
        }
    };
})

.controller('Employees', function($scope, $http) {
	$scope.urlService = "http://localhost:8084/employees";
	$scope.showListEmployes = true;
	$scope.showPhoto = false;
	$scope.photo = false;
	$scope.showDivs = function(employeeList){	
		if (employeeList){
			$scope.showNewForm = false;
			$scope.showListEmployes = true;			
		}else{
			$scope.formTitle = "Add New Employee"
			$scope.id = "";
			$scope.firstName = "";
			$scope.lastName = "";
			$scope.birthDate = "";
			$scope.phone = "";
			$scope.email = "";
			$scope.title = "";
			$scope.dept = "";
			$scope.file = "";
			$scope.showPhoto = false;
			angular.element(document.getElementById("pic")).val(null);
			$scope.showNewForm = true;
			$scope.showListEmployes = false;		
		}
	}
	
	$scope.reset = function(form) {
    if (form) {
      form.$setPristine();
      form.$setUntouched();
    }
  };
  
	//Get employee list
	$scope.getEmployees = function(){
		$http.get($scope.urlService).
			then(function(response) {
				$scope.employees = response.data;
			});
		$scope.searchText = "";
	}
	//Add/Update Employee	
	$scope.submitEmployee = function(){		
		if ($scope.file == undefined){
			$scope.file = null;
		}		
		var formData = new FormData();						
		formData.append('photo',$scope.file);
		formData.append('firstName',$scope.firstName);
		formData.append('lastName',$scope.lastName);
		formData.append('email',$scope.email);
		formData.append('birthDate',$scope.birthDate);
		formData.append('title',$scope.title);
		formData.append('dept',$scope.dept);
		formData.append('phone',$scope.phone);
		
		var res;
		if ($scope.id ==""){		
			res = $http.post($scope.urlService, formData, {
				transformRequest: angular.identity,
				headers: { 'Content-Type': undefined}});
		}else{
			formData.append('phone',$scope.id);
			res = $http.put($scope.urlService+"/"+$scope.id, formData, {
				transformRequest: angular.identity,
				headers: { 'Content-Type': undefined}});
		}
		res.success(function(data, status, headers, config) {
			$scope.message = data;
			$scope.getEmployees();
			$scope.showDivs(true);
			
		});
		res.error(function(data, status, headers, config) {
			alert( "failure message: " + JSON.stringify({data: data}));
		});	
	
	}
	
	//Delete employee
	$scope.deleteEmployee = function() {
		res = $http.delete($scope.urlService+"/"+$scope.id);
		res.success(function(data, status, headers, config) {
			$scope.getEmployees();
			$scope.showDivs(true);
			
		});
		res.error(function(data, status, headers, config) {
			alert( "failure message: " + JSON.stringify({data: data}));
		});	
	}
	
	//Search Employees
	$scope.searchEmployees = function (){
		$http.get($scope.urlService+"/"+$scope.searchType+"/"+$scope.searchText).
			then(function(response) {
				$scope.employees = response.data;
			});
	}
	
	$scope.showDetail = function(employee){
		$scope.showDivs(false);
		$scope.showPhoto = true;
		console.log(employee.id);
		$scope.formTitle = "Update Employee"
		$scope.id = employee.id;
		$scope.photo = employee.photo;
		$scope.firstName = employee.firstName;
		$scope.lastName = employee.lastName;
		$scope.birthDate = employee.birthDate;
		$scope.phone = employee.phone;
		$scope.email = employee.email;
		$scope.title = employee.title;
		$scope.dept = employee.dept;
	}
	

});

