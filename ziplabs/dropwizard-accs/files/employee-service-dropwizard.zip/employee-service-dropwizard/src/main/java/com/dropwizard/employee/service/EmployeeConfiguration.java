package com.dropwizard.employee.service;

import io.dropwizard.Configuration;


public class EmployeeConfiguration extends Configuration {


}