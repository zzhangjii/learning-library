package com.dropwizard.employee.service;

import java.util.List;

public interface EmployeeDAO {

    List<Employee> findAll();
    List<Employee> findById(long id);
    List<Employee> findAllByLastName(String lastName);
    List<Employee> findByDepartment(String department);
    List<Employee> findAllByTitle(String title);
    boolean insert(Employee employee);
    boolean update(Employee employee);
    boolean updateNoPhoto(Employee employee);
    boolean delete(long id);
   
}
