/* Copyright © 2017 Oracle and/or its affiliates. All rights reserved. */
package com.dropwizard.employee.service;

import java.util.concurrent.CopyOnWriteArrayList;

public class MockEmployeeList {

    private static final CopyOnWriteArrayList<Employee> eList = new CopyOnWriteArrayList<>();

    static {
        byte[] photoData = null;
        
        eList.add(
            new Employee(100, "Hugh", "Jast", "1970-11-28T08:28:48.078Z",
                "National Data Strategist", "Mobility",
                "Hugh.Jast@example.com", "730-715-4446", photoData)
        );

        eList.add(
            new Employee(101, "Toy", "Herzog", "1961-08-08T11:39:27.324Z",
                "Dynamic Operations Manager", "Paradigm",
                "Toy.Herzog@example.com", "769-569-1789", photoData)
        );

        eList.add(
            new Employee(102, "Reed", "Hahn", "1977-02-05T19:18:57.407Z",
                "Future Directives Facilitator", "Quality",
                "Reed.Hahn@example.com", "429-071-2018", photoData)
        );

        eList.add(
            new Employee(103, "Novella", "Bahringer", "1961-07-25T10:59:55.485Z",
                "Principal Factors Architect", "Division",
                "Novella.Bahringer@example.com", "293-596-3547", photoData)
        );

        eList.add(
            new Employee(104, "Zora", "Sawayn", "1978-03-18T17:00:12.938Z",
                "Dynamic Marketing Designer", "Security",
                "Zora.Sawayn@example.com", "923-814-0502", photoData)
        );

        eList.add(
            new Employee(105, "Cordia", "Willms", "1989-03-31T23:03:51.599Z",
                "Human Division Representative", "Optimization",
                "Cordia.Willms@example.com", "778-821-3941", photoData)
        );

        eList.add(
            new Employee(106, "Clair", "Bartoletti", "1986-01-04T01:19:47.243Z",
                "Customer Marketing Executive", "Factors",
                "Clair.Bartoletti@example.com", "647-896-8993", photoData)
        );

        eList.add(
            new Employee(107, "Joe", "Beahan", "1990-07-11T23:42:02.063Z",
                "District Group Specialist", "Program",
                "Joe.Beahan@example.com", "548-890-6181", photoData)
        );

        eList.add(
            new Employee(108, "Daphney", "Feest", "1984-03-26T16:32:41.332Z",
                "Dynamic Mobility Consultant", "Metrics",
                "Daphney.Feest@example.com", "143-967-7041", photoData)
        );

        eList.add(
            new Employee(109, "Janessa", "Wyman", "1985-09-06T10:34:05.540Z",
                "Investor Brand Associate", "Markets",
                "Janessa.Wyman@example.com", "498-186-9009", photoData)
        );

        eList.add(
            new Employee(110, "Mara", "Roob", "1975-05-11T09:45:58.248Z",
                "Legacy Assurance Engineer", "Usability",
                "Mara.Roob@example.com", "962-540-9884", photoData)
        );

        eList.add(
            new Employee(111, "Brennon", "Bernhard", "1963-12-05T20:32:26.668Z",
                "Product Web Officer", "Interactions",
                "Brennon.Bernhard@example.com", "395-224-9853", photoData)
        );

        eList.add(
            new Employee(112, "Amya", "Bernier", "1972-06-23T15:25:40.799Z",
                "Global Tactics Planner", "Program",
                "Amya.Bernier@example.com", "563-562-4171", photoData)
        );

        eList.add(
            new Employee(113, "Claud", "Boehm", "1965-02-27T14:09:28.325Z",
                "National Marketing Associate", "Directives",
                "Claud.Boehm@example.com", "089-073-7399", photoData)
        );

        eList.add(
            new Employee(114, "Nyah", "Schowalter", "1969-02-19T19:34:55.044Z",
                "Dynamic Communications Assistant", "Metrics",
                "Nyah.Schowalter@example.com", "823-063-7120", photoData)
        );

        eList.add(
            new Employee(115, "Imogene", "Bernhard", "1958-02-09T15:03:53.070Z",
                "Dynamic Assurance Supervisor", "Paradigm",
                "Imogene.Bernhard@example.com", "747-970-6062", photoData)
        );

        eList.add(
            new Employee(116, "Chanel", "Kuhlman", "1985-03-03T18:12:15.936Z",
                "District Paradigm Representative", "Integration",
                "Chanel.Kuhlman@example.com", "882-145-9513", photoData)
        );

        eList.add(
            new Employee(117, "Cierra", "Morar", "1965-01-25T20:17:32.836Z",
                "Dynamic Data Planner", "Paradigm",
                "Cierra.Morar@example.com", "273-607-2209", photoData)
        );

        eList.add(
            new Employee(118, "Faye", "Grimes", "1962-08-21T07:52:29.284Z",
                "Central Applications Analyst", "Tactics",
                "Faye.Grimes@example.com", "750-139-1344", photoData)
        );

        eList.add(
            new Employee(119, "Doyle", "Rohan", "1991-11-29T17:19:01.536Z",
                "Corporate Accountability Supervisor", "Applications",
                "Doyle.Rohan@example.com", "093-457-5621", photoData)
        );

        eList.add(
            new Employee(120, "Jonathan", "Barrows", "1963-12-15T07:40:48.738Z",
                "Regional Configuration Liason", "Implementation",
                "Jonathan.Barrows@example.com", "262-503-2161", photoData)
        );

        eList.add(
            new Employee(121, "Myriam", "Luettgen", "1962-02-08T10:09:10.361Z",
                "Central Functionality Specialist", "Accountability",
                "Myriam.Luettgen@example.com", "951-924-8295", photoData)
        );

        eList.add(
            new Employee(122, "Johnnie", "Schiller", "1965-04-11T02:03:48.333Z",
                "Principal Creative Developer", "Interactions",
                "Johnnie.Schiller@example.com", "534-025-2200", photoData)
        );

        eList.add(
            new Employee(123, "Laila", "White", "1956-01-04T02:01:09.619Z",
                "Corporate Optimization Engineer", "Assurance",
                "Laila.White@example.com", "468-939-2298", photoData)
        );

        eList.add(
            new Employee(124, "Alessandra", "Becker", "1984-08-12T05:32:50.509Z",
                "Central Identity Associate", "Quality",
                "Alessandra.Becker@example.com", "081-724-0866", photoData)
        );

        eList.add(
            new Employee(125, "Shannon", "McCullough", "1989-02-25T07:47:10.774Z",
                "Global Data Engineer", "Division",
                "Shannon.McCullough@example.com", "101-995-1089", photoData)
        );

        eList.add(
            new Employee(126, "Garnet", "Labadie", "1990-01-01T05:31:28.531Z",
                "Senior Communications Producer", "Program",
                "Garnet.Labadie@example.com", "147-954-6624", photoData)
        );

        eList.add(
            new Employee(127, "Mark", "Graham", "1991-08-23T11:17:47.950Z",
                "Legacy Directives Agent", "Assurance",
                "Mark.Graham@example.com", "462-746-7388", photoData)
        );

        eList.add(
            new Employee(128, "Tristin", "Bayer", "1964-03-26T17:49:29.143Z",
                "Internal Marketing Officer", "Intranet",
                "Tristin.Bayer@example.com", "882-044-3996", photoData)
        );

        eList.add(
            new Employee(129, "Maurice", "Renner", "1973-11-05T18:41:06.678Z",
                "National Accountability Planner", "Accounts",
                "Maurice.Renner@example.com", "383-435-0943", photoData)
        );

        eList.add(
            new Employee(130, "Preston", "Stark", "1994-02-02T10:24:40.312Z",
                "Corporate Program Orchestrator", "Integration",
                "Preston.Stark@example.com", "080-698-9552", photoData)
        );

        eList.add(
            new Employee(131, "Mabelle", "Herman", "1956-11-30T09:45:45.699Z",
                "Human Identity Officer", "Integration",
                "Mabelle.Herman@example.com", "778-672-2787", photoData)
        );

        eList.add(
            new Employee(132, "Juvenal", "Swaniawski", "1963-11-17T06:51:48.742Z",
                "Future Program Planner", "Response",
                "Juvenal.Swaniawski@example.com", "349-906-2745", photoData)
        );

        eList.add(
            new Employee(133, "Rachelle", "Okuneva", "1992-05-27T04:39:16.831Z",
                "District Creative Architect", "Paradigm",
                "Rachelle.Okuneva@example.com", "134-565-3868", photoData)
        );

        eList.add(
            new Employee(134, "Macey", "Weissnat", "1978-06-24T06:38:18.125Z",
                "Product Accountability Facilitator", "Data",
                "Macey.Weissnat@example.com", "210-461-3749", photoData)
        );

        eList.add(
            new Employee(135, "Ena", "Gerlach", "1976-04-09T22:36:01.397Z",
                "Human Tactics Agent", "Creative",
                "Ena.Gerlach@example.com", "429-925-7634", photoData)
        );

        eList.add(
            new Employee(136, "Darrick", "Deckow", "1956-10-25T01:05:22.507Z",
                "Lead Solutions Producer", "Metrics",
                "Darrick.Deckow@example.com", "549-222-4121", photoData)
        );

        eList.add(
            new Employee(137, "Palma", "Torp", "1967-06-24T15:42:05.485Z",
                "Product Infrastructure Consultant", "Response",
                "Palma.Torp@example.com", "346-556-3517", photoData)
        );

        eList.add(
            new Employee(138, "Lucious", "Steuber", "1961-11-24T16:19:53.598Z",
                "District Creative Supervisor", "Mobility",
                "Lucious.Steuber@example.com", "977-372-2840", photoData)
        );

        eList.add(
            new Employee(139, "Kacey", "Kilback", "1957-09-06T10:07:09.719Z",
                "Corporate Mobility Agent", "Infrastructure",
                "Kacey.Kilback@example.com", "268-777-2011", photoData)
        );

    }

    private MockEmployeeList() {
    }

    public static CopyOnWriteArrayList<Employee> getInstance() {
        return eList;
    }

}
