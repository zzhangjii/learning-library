/* Copyright © 2017 Oracle and/or its affiliates. All rights reserved. */
package com.dropwizard.employee.service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;

public class EmployeeListDAO implements EmployeeDAO {

    private final CopyOnWriteArrayList<Employee> eList = MockEmployeeList.getInstance();

    @Override
    public List<Employee> findAll() {
        return eList;
    }

    @Override
    public List<Employee> findById(long id) {
        List<Employee> match = new ArrayList<>();

        eList.stream()
            .filter(e -> e.getId() == id)
            .findFirst().ifPresent(e -> match.add(e));

        return match;
    }

    @Override
    public List<Employee> findAllByLastName(String name) {

        List<Employee> matchList
            = eList.stream()
                .filter((e) -> (e.getLastName().contains(name)))
                .collect(Collectors.toList());

        return matchList;
    }

    @Override
    public List<Employee> findAllByTitle(String title) {
        List<Employee> matchList
            = eList.stream()
                .filter((e) -> (e.getTitle().contains(title)))
                .collect(Collectors.toList());

        return matchList;
    }

    @Override
    public List<Employee> findByDepartment(String dept) {
        List<Employee> matchList
            = eList.stream()
                .filter((e) -> (e.getDept().contains(dept)))
                .collect(Collectors.toList());

        return matchList;
    }

    @Override
    public boolean insert(Employee employee) {
        long next = eList.size() + 100;

        Employee nextEmployee
            = new Employee(next, employee.getFirstName(), employee.getLastName(),
                employee.getBirthDate(), employee.getTitle(), employee.getDept(),
                employee.getEmail(), employee.getPhone(), employee.getPhoto());

        eList.add(nextEmployee);
        return true;
    }

    @Override
    public boolean update(Employee employee) {
        int matchIndex = -1;

        matchIndex = eList.stream()
            .filter(e -> e.getId() == employee.getId())
            .findFirst()
            .map(e -> eList.indexOf(e))
            .orElse(matchIndex);

        if (matchIndex > -1) {
            eList.set(matchIndex, employee);
            return true;
        } else {
            return false;
        }

    }

    @Override
    public boolean updateNoPhoto(Employee employee) {
        int matchIndex = -1;

        matchIndex = eList.stream()
            .filter(e -> e.getId() == employee.getId())
            .findFirst()
            .map(e -> eList.indexOf(e))
            .orElse(matchIndex);

        if (matchIndex > -1) {
            eList.set(matchIndex, employee);
            return true;
        } else {
            return false;
        }

    }

    @Override
    public boolean delete(long id) {
        int matchIndex = -1;

        matchIndex = eList.stream()
            .filter(e -> e.getId() == id)
            .findFirst()
            .map(e -> eList.indexOf(e))
            .orElse(matchIndex);

        if (matchIndex > -1) {
            eList.remove(matchIndex);
            return true;
        } else {
            return false;
        }
    }

}
