#!/bin/sh
export PYTHONPATH=modules
python myapp.py