This is the CRM Demo API that is MAX compatible and use with the MAX Tutorial.

The following artifacts are included in this package:
    API CRM v.3.7 => APIImplementation crm v3.7.1
