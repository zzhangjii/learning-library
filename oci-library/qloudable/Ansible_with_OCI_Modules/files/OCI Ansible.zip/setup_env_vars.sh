# root compartment of bmcs-dex-us-ashburn-1
export SAMPLE_COMPARTMENT_OCID=ocid1.tenancy.oc1..aaaaaaaakgx6v7iy7hne3otsisgxtwak3yg5stsltgxkr3gr3nqszlj74gqa

# Canonical-Ubuntu-16.04-2019.07.12-0
# export SAMPLE_IMAGE_OCID=ocid1.image.oc1.iad.aaaaaaaamoffq7fcfswyd3zdt4nv7wcj4qpay7re2fmiqn2rax3sekzyi4ba

# Oracle-Linux-7.6-2019.07.15-0
export SAMPLE_IMAGE_OCID=ocid1.image.oc1.phx.aaaaaaaajpign274mukkdwjqbzqanem4xqcmvu4mip3jbf5kzhrplqjwdkfq
export SAMPLE_AD_NAME=UpCO:PHX-AD-1

# skip host verification prompts for demo
export ANSIBLE_HOST_KEY_CHECKING=False
